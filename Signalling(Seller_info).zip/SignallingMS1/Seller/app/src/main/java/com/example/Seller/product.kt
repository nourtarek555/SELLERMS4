package com.example.Seller

data class Product(
    val productId: String? = null,
    val name: String? = null,
    val price: String? = null,
    val stock: String? = null,
    val photoUrl: String? = null
)