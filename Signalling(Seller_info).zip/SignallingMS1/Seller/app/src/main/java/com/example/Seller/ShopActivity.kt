package com.example.Seller

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.bumptech.glide.Glide

class ShopActivity : AppCompatActivity() {

    private lateinit var btnAddProduct: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: ProductAdapter
    private lateinit var productList: MutableList<Product>

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products) // ✅ make sure your layout is named correctly

        btnAddProduct = findViewById(R.id.btn_add_product)
        recyclerView = findViewById(R.id.recycler_products)
        progressBar = findViewById(R.id.shopProgress)

        auth = FirebaseAuth.getInstance()
        val uid = auth.currentUser?.uid

        recyclerView.layoutManager = LinearLayoutManager(this)
        productList = mutableListOf()
        adapter = ProductAdapter(productList)
        recyclerView.adapter = adapter

        btnAddProduct.setOnClickListener {
            startActivity(Intent(this, ProductsActivity::class.java))
        }

        if (uid != null) {
            database = FirebaseDatabase.getInstance().getReference("Seller").child(uid).child("Products")
            loadProducts()
        } else {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadProducts() {
        progressBar.visibility = View.VISIBLE

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                productList.clear()
                for (productSnapshot in snapshot.children) {
                    val product = productSnapshot.getValue(Product::class.java)
                    if (product != null) productList.add(product)
                }
                adapter.notifyDataSetChanged()
                progressBar.visibility = View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
                Toast.makeText(this@ShopActivity, "Failed to load products", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

