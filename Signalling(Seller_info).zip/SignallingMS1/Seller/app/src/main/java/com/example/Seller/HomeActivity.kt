package com.example.Seller

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    private lateinit var btnGoToProfile: Button
    private lateinit var btnGoToproducts: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home) // Make sure your XML file is named activity_home.xml

        // Initialize the button
        btnGoToProfile = findViewById(R.id.btnGoToProfile)
        btnGoToproducts = findViewById(R.id.btnGoToproducts)

        // Set click listener to go to ProfileActivity
        btnGoToProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        btnGoToproducts.setOnClickListener {
            val intent = Intent(this, ShopActivity::class.java)
            startActivity(intent)
        }
    }
}
