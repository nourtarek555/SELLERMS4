package com.example.Seller

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class OrdersActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders)

        if (savedInstanceState == null) {
            val fragment = OrdersListFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
        }
    }

    fun showOrderDetails(order: Order) {
        try {
            val fragment = OrderDetailsFragment.newInstance(order)
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

