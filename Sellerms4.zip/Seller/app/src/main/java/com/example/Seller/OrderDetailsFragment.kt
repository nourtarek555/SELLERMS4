package com.example.Seller

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class OrderDetailsFragment : Fragment() {

    private lateinit var orderIdText: TextView
    private lateinit var buyerNameText: TextView
    private lateinit var buyerEmailText: TextView
    private lateinit var buyerPhoneText: TextView
    private lateinit var statusText: TextView
    private lateinit var totalAmountText: TextView
    private lateinit var itemsRecyclerView: RecyclerView
    private lateinit var acceptBtn: Button
    private lateinit var rejectBtn: Button
    private lateinit var readyBtn: Button
    private lateinit var backBtn: Button
    private lateinit var progressBar: ProgressBar

    private lateinit var auth: FirebaseAuth
    private var currentOrder: Order? = null
    private lateinit var itemsAdapter: OrderItemAdapter

    companion object {
        private const val ARG_ORDER = "order"

        fun newInstance(order: Order): OrderDetailsFragment {
            val fragment = OrderDetailsFragment()
            val args = Bundle()
            args.putSerializable(ARG_ORDER, order)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_order_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()

        orderIdText = view.findViewById(R.id.orderIdText)
        buyerNameText = view.findViewById(R.id.buyerNameText)
        buyerEmailText = view.findViewById(R.id.buyerEmailText)
        buyerPhoneText = view.findViewById(R.id.buyerPhoneText)
        statusText = view.findViewById(R.id.statusText)
        totalAmountText = view.findViewById(R.id.totalAmountText)
        itemsRecyclerView = view.findViewById(R.id.itemsRecyclerView)
        acceptBtn = view.findViewById(R.id.acceptBtn)
        rejectBtn = view.findViewById(R.id.rejectBtn)
        readyBtn = view.findViewById(R.id.readyBtn)
        backBtn = view.findViewById(R.id.backBtn)
        progressBar = view.findViewById(R.id.detailsProgress)

        // Get order from arguments
        currentOrder = arguments?.getSerializable(ARG_ORDER) as? Order

        if (currentOrder == null) {
            Toast.makeText(requireContext(), "Order not found", Toast.LENGTH_SHORT).show()
            requireActivity().onBackPressed()
            return
        }

        displayOrderDetails()
        setupButtons()
    }

    private fun displayOrderDetails() {
        val order = currentOrder ?: return

        // Show full order ID for clarity
        orderIdText.text = "Order ID: ${order.orderId ?: "N/A"}"
        buyerNameText.text = "Buyer: ${order.buyerName ?: "N/A"}"
        buyerEmailText.text = "Email: ${order.buyerEmail ?: "N/A"}"
        buyerPhoneText.text = "Phone: ${order.buyerPhone ?: "N/A"}"
        
        // Status explanation: pending means waiting for seller approval
        val statusDisplay = when (order.status?.lowercase()) {
            "pending" -> "Status: PENDING (Waiting for your approval)"
            "accepted" -> "Status: ACCEPTED (Order is being prepared)"
            "rejected" -> "Status: REJECTED"
            "ready" -> "Status: READY (Ready for pickup/delivery)"
            else -> "Status: ${order.status?.uppercase() ?: "N/A"}"
        }
        statusText.text = statusDisplay
        totalAmountText.text = "Total Amount: $${String.format("%.2f", order.totalAmount ?: 0.0)}"

        // Setup items RecyclerView
        val items = order.items ?: mutableListOf()
        if (items.isEmpty()) {
            Toast.makeText(requireContext(), "No items in this order", Toast.LENGTH_SHORT).show()
        }
        
        itemsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        itemsAdapter = OrderItemAdapter(items)
        itemsRecyclerView.adapter = itemsAdapter

        updateButtonVisibility()
    }

    private fun updateButtonVisibility() {
        val status = currentOrder?.status?.lowercase()

        when (status) {
            "pending" -> {
                acceptBtn.visibility = View.VISIBLE
                acceptBtn.text = "Accept Order"
                rejectBtn.visibility = View.VISIBLE
                rejectBtn.text = "Decline Order"
                readyBtn.visibility = View.GONE
            }
            "accepted" -> {
                acceptBtn.visibility = View.GONE
                rejectBtn.visibility = View.GONE
                readyBtn.visibility = View.VISIBLE
                readyBtn.text = "Mark as Ready"
            }
            "ready", "rejected" -> {
                acceptBtn.visibility = View.GONE
                rejectBtn.visibility = View.GONE
                readyBtn.visibility = View.GONE
            }
            else -> {
                // Default to showing accept/reject if status is null or unknown
                acceptBtn.visibility = View.VISIBLE
                acceptBtn.text = "Accept Order"
                rejectBtn.visibility = View.VISIBLE
                rejectBtn.text = "Decline Order"
                readyBtn.visibility = View.GONE
            }
        }
    }

    private fun setupButtons() {
        backBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        acceptBtn.setOnClickListener {
            currentOrder?.let { acceptOrder(it) }
        }

        rejectBtn.setOnClickListener {
            currentOrder?.let { rejectOrder(it) }
        }

        readyBtn.setOnClickListener {
            currentOrder?.let { markReady(it) }
        }
    }

    private fun acceptOrder(order: Order) {
        val orderId = order.orderId ?: return
        val orderRef = FirebaseDatabase.getInstance().getReference("Orders").child(orderId)

        progressBar.visibility = View.VISIBLE

        // Update status at order level in Firebase
        orderRef.child("status").setValue("accepted")
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Order accepted successfully!", Toast.LENGTH_SHORT).show()
                currentOrder?.status = "accepted"
                displayOrderDetails() // Refresh display to show updated status
                updateButtonVisibility()
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Failed to accept order: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun rejectOrder(order: Order) {
        val orderId = order.orderId ?: return
        val orderRef = FirebaseDatabase.getInstance().getReference("Orders").child(orderId)
        val sellerId = auth.currentUser?.uid ?: return

        progressBar.visibility = View.VISIBLE

        // Update order status at order level in Firebase
        orderRef.child("status").setValue("rejected")
            .addOnSuccessListener {
                // Restore inventory for each item
                restoreInventory(order, sellerId)
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Failed to decline order: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun restoreInventory(order: Order, sellerId: String) {
        val items = order.items ?: return
        val database = FirebaseDatabase.getInstance().getReference("Seller")
            .child(sellerId)
            .child("Products")

        var completed = 0
        val total = items.size

        if (total == 0) {
            progressBar.visibility = View.GONE
            Toast.makeText(requireContext(), "Order declined successfully!", Toast.LENGTH_SHORT).show()
            currentOrder?.status = "rejected"
            displayOrderDetails() // Refresh display to show updated status
            updateButtonVisibility()
            return
        }

        items.forEach { item ->
            val productId = item.productId ?: return@forEach
            val quantity = item.quantity ?: 0

            database.child(productId).child("stock")
                .get()
                .addOnSuccessListener { snapshot ->
                    val currentStock = when (val stockValue = snapshot.value) {
                        is Long -> stockValue.toInt()
                        is Int -> stockValue
                        is String -> stockValue.toIntOrNull() ?: 0
                        else -> 0
                    }

                    val newStock = currentStock + quantity
                    database.child(productId).child("stock").setValue(newStock)
                        .addOnSuccessListener {
                            completed++
                            if (completed == total) {
                                progressBar.visibility = View.GONE
                                Toast.makeText(
                                    requireContext(),
                                    "Order declined and inventory restored",
                                    Toast.LENGTH_SHORT
                                ).show()
                                currentOrder?.status = "rejected"
                                displayOrderDetails() // Refresh display to show updated status
                                updateButtonVisibility()
                            }
                        }
                        .addOnFailureListener {
                            completed++
                            if (completed == total) {
                                progressBar.visibility = View.GONE
                                Toast.makeText(
                                    requireContext(),
                                    "Order declined (some inventory updates may have failed)",
                                    Toast.LENGTH_SHORT
                                ).show()
                                currentOrder?.status = "rejected"
                                displayOrderDetails() // Refresh display to show updated status
                                updateButtonVisibility()
                            }
                        }
                }
                .addOnFailureListener {
                    completed++
                    if (completed == total) {
                        progressBar.visibility = View.GONE
                        Toast.makeText(
                            requireContext(),
                            "Order declined (inventory update failed)",
                            Toast.LENGTH_SHORT
                        ).show()
                        currentOrder?.status = "rejected"
                        displayOrderDetails() // Refresh display to show updated status
                        updateButtonVisibility()
                    }
                }
        }
    }

    private fun markReady(order: Order) {
        val orderId = order.orderId ?: return
        val orderRef = FirebaseDatabase.getInstance().getReference("Orders").child(orderId)

        progressBar.visibility = View.VISIBLE

        orderRef.child("status").setValue("ready")
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Order marked as ready", Toast.LENGTH_SHORT).show()
                currentOrder?.status = "ready"
                updateButtonVisibility()
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

