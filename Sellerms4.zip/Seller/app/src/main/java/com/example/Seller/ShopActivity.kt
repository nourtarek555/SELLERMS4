package com.example.Seller

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.bumptech.glide.Glide

class ShopActivity : AppCompatActivity() {

    private lateinit var btnAddProduct: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: ProductAdapter
    private lateinit var productList: MutableList<Product>

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products)

        try {
            btnAddProduct = findViewById(R.id.btn_add_product)
            recyclerView = findViewById(R.id.recycler_products)
            progressBar = findViewById(R.id.shopProgress)

            auth = FirebaseAuth.getInstance()
            val uid = auth.currentUser?.uid

            recyclerView.layoutManager = LinearLayoutManager(this)
            productList = mutableListOf()
            adapter = ProductAdapter(productList)
            recyclerView.adapter = adapter

            btnAddProduct.setOnClickListener {
                try {
                    startActivity(Intent(this, ProductsActivity::class.java))
                } catch (e: Exception) {
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    e.printStackTrace()
                }
            }

            if (uid != null) {
                database = FirebaseDatabase.getInstance().getReference("Seller").child(uid).child("Products")
                loadProducts()
            } else {
                Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error initializing: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun loadProducts() {
        try {
            if (!::database.isInitialized) {
                Toast.makeText(this, "Database not initialized", Toast.LENGTH_SHORT).show()
                return
            }
            
            progressBar.visibility = View.VISIBLE

            database.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    try {
                        productList.clear()

                        if (!snapshot.exists()) {
                            adapter.notifyDataSetChanged()
                            progressBar.visibility = View.GONE
                            return
                        }

                        for (productSnapshot in snapshot.children) {
                            try {
                                val product = productSnapshot.getValue(Product::class.java)

                                if (product != null) {
                                    // Safely handle stock whether it's a Long, String, or Int
                                    val stockValue = when (val stockAny = productSnapshot.child("stock").value) {
                                        is Long -> stockAny.toInt()
                                        is Int -> stockAny
                                        is String -> stockAny.toIntOrNull() ?: 0
                                        else -> 0
                                    }

                                    // Keep only products with stock > 0
                                    if (stockValue > 0) {
                                        productList.add(product)
                                    }
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                                // Skip invalid products
                            }
                        }

                        adapter.notifyDataSetChanged()
                        progressBar.visibility = View.GONE
                    } catch (e: Exception) {
                        e.printStackTrace()
                        progressBar.visibility = View.GONE
                        Toast.makeText(this@ShopActivity, "Error loading products: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this@ShopActivity, "Failed to load products: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
        } catch (e: Exception) {
            progressBar.visibility = View.GONE
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            e.printStackTrace()
        }
    }


}

