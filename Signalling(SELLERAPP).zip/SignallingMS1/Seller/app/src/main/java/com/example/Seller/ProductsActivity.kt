package com.example.Seller

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.regions.Regions
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.CannedAccessControlList
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import java.util.*

class ProductsActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    private lateinit var nameEt: EditText
    private lateinit var priceEt: EditText
    private lateinit var stockEt: EditText
    private lateinit var imageView: ImageView
    private lateinit var uploadBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var progressBar: ProgressBar

    private var imageUri: Uri? = null
    private val PICK_IMAGE_REQUEST = 101

    // Replace with your AWS credentials
    private val ACCESS_KEY = "AKIA6GUTHW7W2GIYEQMP"
    private val SECRET_KEY = "ZcEDd/zXIGOcOyBLoj6r5ef6VAac89KAw6CpH/sB"
    private val BUCKET_NAME = "madrid-fans"
    private val REGION = Regions.EU_NORTH_1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items)

        auth = FirebaseAuth.getInstance()

        nameEt = findViewById(R.id.etName)
        priceEt = findViewById(R.id.price)
        stockEt = findViewById(R.id.stock)
        imageView = findViewById(R.id.profileImage)
        uploadBtn = findViewById(R.id.btnUpload)
        saveBtn = findViewById(R.id.btnSave)
        progressBar = findViewById(R.id.ProductProgress)

        uploadBtn.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        saveBtn.setOnClickListener {
            saveProduct()
        }
    }

    private fun saveProduct() {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            Toast.makeText(this, "User not logged in!", Toast.LENGTH_SHORT).show()
            return
        }

        val name = nameEt.text.toString().trim()
        val price = priceEt.text.toString().trim()
        val stock = stockEt.text.toString().trim()

        if (name.isEmpty() || price.isEmpty() || stock.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        progressBar.visibility = View.VISIBLE
        val productId = UUID.randomUUID().toString()

        val productData = mutableMapOf<String, Any>(
            "productId" to productId,
            "name" to name,
            "price" to price,
            "stock" to stock,
            "sellerId" to uid
        )

        if (imageUri != null) {
            Glide.with(this)
                .load(imageUri)
                .placeholder(R.drawable.ic_person)
                .into(imageView)

            uploadImageToS3(productId, imageUri!!) { imageUrl ->
                productData["photoUrl"] = imageUrl
                updateDatabase(uid, productId, productData)
            }
        } else {
            updateDatabase(uid, productId, productData)
        }
    }

    private fun uploadImageToS3(productId: String, uri: Uri, callback: (String) -> Unit) {
        val credentials = BasicAWSCredentials(ACCESS_KEY, SECRET_KEY)
        val s3Client = AmazonS3Client(credentials, com.amazonaws.regions.Region.getRegion(REGION))
        val transferUtility = TransferUtility.builder()
            .context(applicationContext)
            .s3Client(s3Client)
            .build()

        val fileName = "product_images/$productId-${System.currentTimeMillis()}.jpg"
        val file = FileUtil.from(this, uri)

        val uploadObserver = transferUtility.upload(
            BUCKET_NAME,
            fileName,
            file,
            CannedAccessControlList.PublicRead
        )

        uploadObserver.setTransferListener(object : TransferListener {
            override fun onStateChanged(id: Int, state: TransferState?) {
                if (state == TransferState.COMPLETED) {
                    val imageUrl = "https://$BUCKET_NAME.s3.amazonaws.com/$fileName"
                    callback(imageUrl)
                } else if (state == TransferState.FAILED) {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this@ProductsActivity, "Upload failed!", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onProgressChanged(id: Int, bytesCurrent: Long, bytesTotal: Long) {}
            override fun onError(id: Int, ex: Exception?) {
                progressBar.visibility = View.GONE
                Toast.makeText(this@ProductsActivity, "Error: ${ex?.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // 👇 Save product inside: Seller/{uid}/Products/{productId}
    private fun updateDatabase(uid: String, productId: String, productData: Map<String, Any>) {
        val databaseRef = FirebaseDatabase.getInstance()
            .getReference("Seller")
            .child(uid)
            .child("Products")
            .child(productId)

        databaseRef.setValue(productData).addOnCompleteListener {
            progressBar.visibility = View.GONE
            if (it.isSuccessful) {
                Toast.makeText(this, "Product added successfully!", Toast.LENGTH_SHORT).show()
                clearFields()

                // ✅ Go back to ShopActivity
                val intent = Intent(this, ShopActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                finish() // close ProductsActivity
            } else {
                Toast.makeText(this, "Failed to add product", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun clearFields() {
        nameEt.text.clear()
        priceEt.text.clear()
        stockEt.text.clear()
        imageView.setImageResource(R.drawable.ic_person)
        imageUri = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            imageUri = data.data
            Glide.with(this)
                .load(imageUri)
                .placeholder(R.drawable.ic_person)
                .into(imageView)
        }
    }
}

